import "./App.css";
import { useState, useEffect } from "react";
import Form from "./components/Form/Form";
import Table from "./components/Table/Table";


function App() {
  const [products, setProducts] = useState([]);
  const [openForm, setOpenForm] = useState(false);

  function fetchRequest(route, method, petitionBody) {
    console.log("method executed : " + method)
    let reqConfig = {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        "authorId" : "57"
      },
      method: method,
    };
    if (petitionBody) {
      reqConfig.body = JSON.stringify(petitionBody);
    }
    fetch(route, reqConfig)
      .then((response) => (response.status == 204 ? null : response.json()))
      .then((products) => {
        console.log(products)
        setProducts(products);
      });
  }

  useEffect(() => {
    fetchRequest('https://tribu-ti-staffing-desarrollo-afangwbmcrhucqfh.z01.azurefd.net/ipf-msa-productosfinancieros/bp/products',"GET",null)
   }, []);

  //  fetchRequest('https://tribu-ti-staffing-desarrollo-afangwbmcrhucqfh.z01.azurefd.net/ipf-msa-productosfinancieros/bp/products',"POST",{
  //   "id" : "3432",
  //   "name" : "refinanciacion",
  //   "description" : "refinanciacion",
  //   "logo" : "https://www.visa.com.ec/dam/VCOM/regional/lac/SPA/Default/Pay%20With%20Visa/Tarjetas/visa-signature-400x225.jpg",
  //   "date_release" : "2023-06-01",
  //   "date_revision" : "2024-06-01"
  // })

console.log("new data fetched"+ products)
  return <div className="App">
            <img src="https://www.bancopichincha.com.co/o/pichincha-theme/images/logo.png" />

    {products && <Table products={products} />}
    {openForm && <Form />}
    </div>;
}

export default App;

